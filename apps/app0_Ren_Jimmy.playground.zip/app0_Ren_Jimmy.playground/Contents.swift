import UIKit

// App 0

let name = "Jimmy Ren"
let favoriteEmoji = "🤑"
let pennId = 11167170

print("Hello World! My name is \(name) and my pennId is \(pennId)")
